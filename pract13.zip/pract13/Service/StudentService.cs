﻿using Microsoft.EntityFrameworkCore;
using Pract12.data;
using Pract12.Models;
using Pract12.Service;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pract12.Service
{
    public class StudentService
    {
        private readonly AppDbContext _db = BaseDbService.Instance.Context;

        public ObservableCollection<Student> Students { get; set; } = new ObservableCollection<Student>();

        public StudentService() 
        {
            GetAll();
        }
        public void Add(Student student)
        {
            var _student = new Student
            {
                FirstName = student.FirstName,
                LastName = student.LastName,
                MiddleName = student.MiddleName,
                Birthday = student.Birthday,
                Passport = student.Passport,
                GroupId = student.GroupId,
                Group = student.Group,
            };
            _db.Add<Student>(_student);
            Commit();
            Students.Add(_student);
        }
        public int Commit() =>_db.SaveChanges();

        public void GetAll()
        {
            var students = _db.Students
                .Include(s => s.Passport)
                .Include(s => s.Group)
                .ToList();
            Students.Clear();
            foreach (var student in students)
            {
                Students.Add(student);
            }

        }
        public void Remove(Student student)
        {
            _db.Remove<Student>(student);
            if (Commit() > 0)
                if (Students.Contains(student))
                    Students.Remove(student);
        }
    }

}

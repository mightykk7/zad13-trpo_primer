﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Pract12.Migrations
{
    /// <inheritdoc />
    public partial class AddTablePassportAndHasOneRelation : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Passport_Students_StudentId",
                table: "Passport");

            migrationBuilder.DropPrimaryKey(
                name: "PK_Passport",
                table: "Passport");

            migrationBuilder.RenameTable(
                name: "Passport",
                newName: "Passports");

            migrationBuilder.RenameIndex(
                name: "IX_Passport_StudentId",
                table: "Passports",
                newName: "IX_Passports_StudentId");

            migrationBuilder.AddPrimaryKey(
                name: "PK_Passports",
                table: "Passports",
                column: "Id");

            migrationBuilder.AddForeignKey(
                name: "FK_Passports_Students_StudentId",
                table: "Passports",
                column: "StudentId",
                principalTable: "Students",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Passports_Students_StudentId",
                table: "Passports");

            migrationBuilder.DropPrimaryKey(
                name: "PK_Passports",
                table: "Passports");

            migrationBuilder.RenameTable(
                name: "Passports",
                newName: "Passport");

            migrationBuilder.RenameIndex(
                name: "IX_Passports_StudentId",
                table: "Passport",
                newName: "IX_Passport_StudentId");

            migrationBuilder.AddPrimaryKey(
                name: "PK_Passport",
                table: "Passport",
                column: "Id");

            migrationBuilder.AddForeignKey(
                name: "FK_Passport_Students_StudentId",
                table: "Passport",
                column: "StudentId",
                principalTable: "Students",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);
        }
    }
}

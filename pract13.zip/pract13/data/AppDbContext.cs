﻿using Microsoft.EntityFrameworkCore;
using Pract12.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;

namespace Pract12.data
{
    public class AppDbContext : DbContext
    {
        public DbSet<Student> Students { get; set; }
        public DbSet<Passport> Passports { get; set; }
        public DbSet<Group> Groups { get; set; }
        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseSqlServer("Server=sql.ects;Database=RatovskijDB;User Id=student_07;Password=student_07;TrustServerCertificate=True;");
        }
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Student>() // отношение один-к-одному
            .HasOne(s => s.Passport)
            .WithOne(ps => ps.Student)
            .HasForeignKey<Passport>(ps => ps.StudentId);
            modelBuilder.Entity<Group>() // отношение один-ко-многим
            .HasMany(g => g.Students)
            .WithOne(s => s.Group)
            .HasForeignKey(s => s.GroupId);
        }

    }
}
